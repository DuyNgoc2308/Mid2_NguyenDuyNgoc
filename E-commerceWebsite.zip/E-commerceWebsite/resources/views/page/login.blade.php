@extends('master')
@section('content')
<div class="inner-header">
    <div class="container">
        <div class="pull-left">
            <h6 class="inner-title">Đăng nhập</h6>
        </div>
        <div class="pull-right">
            <div class="beta-breadcrumb">
                <a href="index.html">Home</a> / <span>Đăng nhập</span>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div class="container">
    <div id="content">

        <form action="{{ route('postlogin')}}" method="post" class="beta-form-checkout">
        @csrf
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                    <h4>Đăng nhập</h4>
                    <div class="space20">&nbsp;</div>


                    <div class="form-block">
                        <label for="email">Email address*</label>
                        <input type="email" id="email" name="email">
                    </div>
                    <div class="form-block">
                        <label for="pwd">Password*</label>
                        <input type="text" id="pwd" name="pwd">
                    </div>
                    <div class="form-block">
                        <button type="submit" class="btn btn-primary" href="{{ route('postlogin')}}">Login</button>
                    </div>
                </div>
                <div class="col-sm-3"></div>
            </div>
        </form>
        @include('block.error')
        @if(isset($user))
        <p>Email: {{$user['email']}}</p>
        <p>Password: {{$user['pwd']}}</p>
        @endif
    </div> <!-- #content -->
</div> <!-- .container -->
@endsection