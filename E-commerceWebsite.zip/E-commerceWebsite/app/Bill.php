<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{
    protected $table='bills';
	protected $fillabel = ['id', 'id_customer', 'date_order', 'total', 'payment', 'note'];
	public $timestamp = true;
}
