<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Session;
use App\Cart;
use App\ProductType;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
            view()->composer('header',function($view){
                $prod_type = ProductType::all();
                $view->with('producttype',$prod_type);
            });

            view()->composer('header',function($view){
                if(Session('cart')){
                    $oldCart = Session::get('cart');
                    $cart = new Cart($oldCart);
                    $view->with(['cart'=>Session::get('cart'),'product_cart'=>$cart->items,
                    'totalPrice'=>$cart->totalPrice,'totalQty'=>$cart->totalQty]);

                }
            });
    }
}
