<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BillDetail extends Model
{
    protected $table='bills_detail';
	protected $fillabel = ['id', 'id_bill', 'id_product', 'quantity', 'unit_price'];
	public $timestamp = true;
}
