<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Slide;
use App\Product;
use App\ProductType;
use App\Cart;
use App\Customer;
use App\Bill;
use App\BillDetail;
use App\User;
use Session;
use App\Http\Requests\ProductRequest;
use App\Http\Requests\SignupRequest;
use App\Http\Requests\LoginRequest;

class PageController extends Controller
{
    public function getIndex(){
        $slide = Slide::all();
        $new_product = Product::where('new',1)->paginate(4);
        $promotion_product = Product::where('promotion_price','<>',0)->paginate(4);
        return view('page.home',compact('slide','new_product','promotion_product'));
    }
    public function getProductType($type){
        //Lay san pham hien thi theo loai
        $sp_theoloai = Product::where('id_type',$type)->limit(3)->get();
        //Lay san pham hien thi khac <> loai
        $sp_khac = Product::where('id_type','<>',$type)->limit(3)->get();
        //Lay san pham hien thi theo loai cho menu ben trai
        $loai = ProductType::all();
        // Lay ten loai san pham moi khi chuc ta chon danh muc loai san pham(phan menu ben trai)
        $loai_sp = ProductType::where('id',$type)->first();
        $new_product = Product::where('new',1)->paginate(4);

        return view('page.producttype',compact('sp_theoloai','sp_khac','loai','loai_sp','new_product'));
    }
    public function getProductDetail(Request $request){
        $product = Product::where('id',$request->id)->first();
        $related_prod = Product::where('id_type',$product->id_type)->paginate(3);
        $best_sellers = Product::where('promotion_price','=',0)->paginate(3);
        $new_product = Product::select('id', 'name', 'id_type', 'description', 'unit_price', 'promotion_price',
         'image', 'unit', 'new', 'created_at', 'updated_at')->where('new','>',0)->orderBy('updated_at','ASC')->paginate(3);
        return view('page.productdetail',compact('product','related_prod','best_sellers','new_product'));
    }
    public function getContact(){
        return view('page.contact');
    }
    public function getAbout(){
        return view('page.about');
    }
    // public function getProductTypeW(){
    //     return view('page.producttype');
    // }
    public function getAddtoCart(Request $request, $id){
        $product = Product::find($id);
        $oldCart = Session('cart')?Session::get('cart'):null;
        $cart = new Cart($oldCart);
        $cart->add($product,$id);
        $request->session()->put('cart', $cart);
        return redirect()->back();
    }
    public function getRemovefromCart($id){
        $oldCart = Session::has('cart')?Session::get('cart'):null;
        $cart = new Cart($oldCart);
        $cart->removeItem($id);
        if(count($cart->items)>0){
            Session::put('cart',$cart);
        }
        else{
            Session::forget('cart');
        }
        return redirect()->back();
    }
    public function getCheckingorder(){
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        return view('page.order')->with(['cart'=>Session::get('cart'),'product_cart'=>$cart->items,
        'totalPrice'=>$cart->totalPrice,'totalQty'=>$cart->totalQty]);
    }
    public function postCheckingorder(Request $request){
        $cart = Session::get('cart');
        $notes = 'nothing';
        if(isset($request->note)){
            $notes = $request->note;
        }
        
        $customer = new Customer;
        $customer->name = $request->full_name;
        $customer->gender = $request->gender;
        $customer->email = $request->email;
        $customer->address = $request->address;
        $customer->phone_number = $request->phone;
        $customer->note = $notes;
        $customer->save();

        $bill = new Bill();
        $bill->id_customer = $customer->id;
        $bill->date_order = date('Y-m-d');
        $bill->total = $cart->totalPrice;
        $bill->payment = $request->payment_method;
        $bill->note = $request->note;
        $bill->save();

        foreach($cart->items as $key=>$value){
            $bill_detail = new BillDetail;
            $bill_detail->id_bill = $bill->id;
            $bill_detail->id_product = $key;//$value['item']['id'];
            $bill_detail->quatity = $value['qty'];
            $bill_detail->unit_price = $value['price']/$value['qty'];
            $bill_detail->save();
        }
        Session::forget('cart');
        return $this->getIndex()->with('thongbao','Đặt hàng thành công');
    }
    public function getLogin(){
        return view('page.login');
    }
    
    public function getSignup(){
        return view('page.signup');
    }
    public function postSignup(signupRequest $request){
        $user = new User();
        $user->email =  $request->email;
        $user->full_name = $request->fullname;
        
        $user->address = $request->address;
        $user->phone = $request->phone;
        $password = $request->pwd;
        $reenter = $request->repwd;
        if($password!=$reenter){
            return $this->getSignup()->with('thongbao','Mật khẩu bạn vừa nhập không chính xác');
            
        }
        else{
            $user->password = password_hash ($reenter, PASSWORD_DEFAULT);
            $user->save();
        }

        return redirect()->action("PageController@getLogin");
    }
    public function postLogin(loginRequest $request){
        $mail =  $request->email;
        $user = User::where('email',$mail)->first();
        
        $pwd = $request->pwd;
        // echo $user->email.'</br>';
        // echo password_hash($pwd, PASSWORD_DEFAULT).'</br>';
        // echo $user->password;
        
        if(isset($user)){
            if(password_verify($pwd, $user->password)){
                Session::put('login','true');
                Session::put('name',$user->full_name);
                return $this->getIndex();
            }else{
                echo 'Mật khẩu không đúng';
            }
        }
        
    }
    public function getLogout(){
        Session::forget('login','name');
        return $this->getLogin();
    }
}