
<?php $__env->startSection('content'); ?>
<div class="inner-header">
    <div class="container">
        <div class="pull-left">
            <h6 class="inner-title">Đăng kí</h6>
        </div>
        <div class="pull-right">
            <div class="beta-breadcrumb">
                <a href="index.html">Home</a> / <span>Đăng kí</span>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div class="container">
    <div id="content">
        <form action="<?php echo e(route('postsignup')); ?>" method="post" class="beta-form-checkout">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                    <h4>Đăng kí</h4>
                    <div class="space20">&nbsp;</div>


                    <div class="form-block">
                        <label for="email">Email address*</label>
                        <input type="email" id="email" name="email">
                    </div>

                    <div class="form-block">
                        <label for="fullname">Fullname*</label>
                        <input type="text" id="fullname" name="fullname">
                    </div>

                    <div class="form-block">
                        <label for="address">Address*</label>
                        <input type="text" id="address" name="address" value="Street Address">
                    </div>


                    <div class="form-block">
                        <label for="phone">Phone*</label>
                        <input type="text" id="phone" name="phone">
                    </div>
                    <div class="form-block">
                        <label for="password">Password*</label>
                        <input type="text" id="password" name="pwd">
                    </div>
                    <div class="form-block">
                        <label for="rePassword">Re-password*</label>
                        <input type="text" id="rePassword" name="repwd">
                    </div>
                    <div class="form-block">
                        <button type="submit" class="btn btn-primary" href="<?php echo e(route('postsignup')); ?>">Register</button>
                    </div>
                </div>
                <div class="col-sm-3"></div>
            </div>
        <?php echo $__env->make('block.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(isset($user)): ?>
        <p>Email: <?php echo e($user['email']); ?></p>
        <p>Full name: <?php echo e($user['fullname']); ?></p>
        <p>Address: <?php echo e($user['address']); ?></p>
        <p>Phone number: <?php echo e($user['phone']); ?></p>
        <p>Password: <?php echo e($user['pwd']); ?></p>
        <p>Re-password: <?php echo e($user['repwd']); ?></p>
        <?php endif; ?>
    </div> <!-- #content -->
</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\E-commerceWebsite\resources\views/page/signup.blade.php ENDPATH**/ ?>