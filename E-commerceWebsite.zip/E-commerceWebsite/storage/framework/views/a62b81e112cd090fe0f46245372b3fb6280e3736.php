
<?php $__env->startSection('content'); ?>

<div class="inner-header">
    <div class="container">
        <div class="pull-left">
            <h6 class="inner-title">Sản phẩm <?php echo e($loai_sp->name); ?></h6>
        </div>
        <div class="pull-right">
            <div class="beta-breadcrumb font-large">
                <a href="index.html">Home</a> / <span>Sản phẩm</span>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<div class="container">
    <div id="content" class="space-top-none">
        <div class="main-content">
            <div class="space60">&nbsp;</div>
            <div class="row">
                <div class="col-sm-3">
                    <ul class="aside-menu">
                        <?php $__currentLoopData = $loai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('producttype',$typep->id)); ?>"><?php echo e($typep->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="col-sm-9">
                    <div class="beta-products-list">
                    <h4>Sản phẩm mới</h4>
                        <div class="beta-products-details">
                            <p class="pull-left"> <?php echo e(count($new_product)); ?> sản phẩm mới</p>
                            <div class="clearfix"></div>
                        </div>

                        <div class="row">
                            <?php $__currentLoopData = $new_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newprod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-3">
                                <div class="single-item">
                                    <?php if($newprod->promotion_price!=0): ?>
                                    <div class="ribbon-wrapper">
                                        <div class="ribbon sale">Flash sale</div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="single-item-header">
                                        <a href="product.html"><img
                                                src="public/source/image/product/<?php echo e($newprod->image); ?>" alt=""></a>
                                    </div>
                                    <div class="single-item-body">
                                        <p class="single-item-title"><?php echo e($newprod->name); ?></p>
                                        <p class="single-item-price">
                                            <span class="flash-del"><?php echo e($newprod->unit_price); ?> đồng</span>
                                            <span class="flash-sale"><?php echo e($newprod->promotion_price); ?> đồng</span>
                                        </p>
                                    </div>
                                    <div class="single-item-caption">
                                        <a class="add-to-cart pull-left" href="<?php echo e(route('addtocart',$newprod->id)); ?>"><i
                                                class="fa fa-shopping-cart"></i></a>
                                        <a class="beta-btn primary" href="<?php echo e(route('productdetail',$newprod->id)); ?>">Chi tiết <i
                                                class="fa fa-chevron-right"></i></a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- .beta-products-list -->

                    <div class="space50">&nbsp;</div>

                    <div class="beta-products-list">
                        <h4>Sản phẩm khác</h4>
                        <div class="beta-products-details">
                            <p class="pull-left"><?php echo e(count($sp_khac)); ?> sản phẩm khác</p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $sp_khac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4">
                                <div class="single-item">
                                    <div class="single-item-header">
                                        <a href="product.html"><img src="public/source/image/product/<?php echo e($spk->image); ?>"
                                                alt=""></a>
                                    </div>
                                    <div class="single-item-body">
                                        <p class="single-item-title"><?php echo e($spk->name); ?></p>
                                        <p class="single-item-price">
                                            <?php if($spk->promotion_price==0): ?>
                                            <span class="flash-sale"><?php echo e(number_format($spk->unit_price)); ?> đồng</span>
                                            <?php else: ?>
                                            <span class="flash-del"><?php echo e(number_format($spk->unit_price)); ?> đồng</span>
                                            <span class="flash-sale"><?php echo e(number_format($spk->promotion_price)); ?>

                                                đồng</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="single-item-caption">
                                        <a class="add-to-cart pull-left" href="<?php echo e(route('addtocart',$spk->id)); ?>"><i
                                                class="fa fa-shopping-cart"></i></a>
                                        <a class="beta-btn primary" href="<?php echo e(route('productdetail',$spk->id)); ?>">Details <i
                                                class="fa fa-chevron-right"></i></a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="space40">&nbsp;</div>

                    </div> <!-- .beta-products-list -->
                </div>
            </div> <!-- end section with sidebar and main content -->


        </div> <!-- .main-content -->
    </div> <!-- #content -->
</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\E-commerceWebsite\resources\views/page/producttype.blade.php ENDPATH**/ ?>