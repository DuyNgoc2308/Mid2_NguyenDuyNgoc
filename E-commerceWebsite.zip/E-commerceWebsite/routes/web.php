<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('index',[
    'as'=>'honepage',
    'uses'=>'PageController@getIndex'
]);
Route::get('type/{type}',[
    'as'=>'producttype',
    'uses'=>'PageController@getProductType'
]);
// Route::get('getproducttype','PageController@getProductTypeW');
Route::get('detail/{id}',[
    'as'=>'productdetail',
    'uses'=>'PageController@getProductDetail'
]);
Route::get('contact',[
    'as'=>'contact',
    'uses'=>'PageController@getContact'
]);
Route::get('about',[
    'as'=>'about',
    'uses'=>'PageController@getAbout'
]);
Route::get('add-to-cart/{id}',[
    'as'=>'addtocart',
    'uses'=>'PageController@getAddtoCart'
]);
Route::get('remove-cart/{id}',[
    'as'=>'removefromcart',
    'uses'=>'PageController@getRemovefromCart'
]);

Route::get('order',[
    'as'=>'order',
    'uses'=>'PageController@getCheckingorder'
]);
Route::post('payorder',[
    'as'=>'payorder',
    'uses'=>'PageController@postCheckingorder'
]);
Route::get('login',[
    'as'=>'login',
    'uses'=>'PageController@getLogin'
]);
Route::post('postlogin',[
    'as'=>'postlogin',
    'uses'=>'PageController@postLogin'
]);
Route::get('signup',[
    'as'=>'signup',
    'uses'=>'PageController@getSignup'
]);
Route::post('postsignup',[
    'as'=>'postsignup',
    'uses'=>'PageController@postSignup'
]);
Route::get('logout',[
    'as'=>'logout',
    'uses'=>'PageController@getLogout'
]);